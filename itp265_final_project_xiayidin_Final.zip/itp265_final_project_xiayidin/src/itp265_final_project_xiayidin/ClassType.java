/**
 * classType Enum; extends from Person;
 * 
 * @author Tony Ding
 * ITP 265, Fall 2020, Gelato Section
 * Final Project
 * Email: xiayidin@usc.edu
 */
package itp265_final_project_xiayidin;

public enum ClassType {
	
	GroupExercise,
	PersonalTraining;
	
}
